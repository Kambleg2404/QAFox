from datetime import datetime
from behave import *
from selenium import webdriver
from selenium.webdriver.common.by import By


@given(u'I navigate to Register Page')
def step_impl(context):
    context.driver = webdriver.Chrome()
    context.driver.maximize_window()
    context.driver.get('https://tutorialsninja.com/demo/')
    context.driver.find_element(By.XPATH, "//span[text()='My Account']").click()
    context.driver.find_element(By.LINK_TEXT, "Register").click()


@when(u'I enter mandatory fields')
def step_impl(context):
    context.driver.find_element(By.ID, "input-firstname").send_keys("Ganesh")
    context.driver.find_element(By.ID, "input-lastname").send_keys("Kamble")
    time_stamp = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
    new_email = "ganeshkamble" + time_stamp + "@gamil.com"
    context.driver.find_element(By.ID, "input-email").send_keys(new_email)
    context.driver.find_element(By.ID, "input-telephone").send_keys("2564086500")
    context.driver.find_element(By.ID, "input-password").send_keys("123456")
    context.driver.find_element(By.ID, "input-confirm").send_keys("123456")


@when(u'I select Privacy policy option')
def step_impl(context):
    context.driver.find_element(By.NAME, "agree").click()


@when(u'I click on Continue')
def step_impl(context):
    context.driver.find_element(By.XPATH, "//input[@value='Continue']").click()


@then(u'Account should get created')
def step_impl(context):
    expected_text = "Your Account Has Been Created!"
    assert context.driver.find_element(By.XPATH, "//div[@id='content']/h1").text == expected_text


@when(u'I enter all fields')
def step_impl(context):
    context.driver.find_element(By.ID, "input-firstname").send_keys("Ganesh")
    context.driver.find_element(By.ID, "input-lastname").send_keys("Kamble")
    time_stamp = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
    new_email = "ganeshkamble" + time_stamp + "@gamil.com"
    context.driver.find_element(By.ID, "input-email").send_keys(new_email)
    context.driver.find_element(By.ID, "input-telephone").send_keys("2564086500")
    context.driver.find_element(By.ID, "input-password").send_keys("123456")
    context.driver.find_element(By.ID, "input-confirm").send_keys("123456")
    context.driver.find_element(By.XPATH, "//input[@name='newsletter'][@value='1']").click()


@when(u'I enter details into all fields except email field')
def step_impl(context):
    context.driver.find_element(By.ID, "input-firstname").send_keys("Ganesh")
    context.driver.find_element(By.ID, "input-lastname").send_keys("Kamble")
    context.driver.find_element(By.ID, "input-telephone").send_keys("2564086500")
    context.driver.find_element(By.ID, "input-password").send_keys("123456")
    context.driver.find_element(By.ID, "input-confirm").send_keys("123456")
    context.driver.find_element(By.XPATH, "//input[@name='newsletter'][@value='1']").click()


@when(u'I enter existing account email into email field')
def step_impl(context):
    context.driver.find_element(By.ID, "input-email").send_keys("kambleganesh3232@gmail.com")


@when(u'I dont enter anything into the fields')
def step_impl(context):
    context.driver.find_element(By.ID, "input-firstname").send_keys("")
    context.driver.find_element(By.ID, "input-lastname").send_keys("")
    context.driver.find_element(By.ID, "input-email").send_keys("")
    context.driver.find_element(By.ID, "input-telephone").send_keys("")
    context.driver.find_element(By.ID, "input-password").send_keys("")
    context.driver.find_element(By.ID, "input-confirm").send_keys("")


@then(u'Proper warning message informing about duplicate account should be displayed')
def step_impl(context):
    expected_warning = "Warning: E-Mail Address is already registered!"
    assert context.driver.find_element(By.XPATH, "//*[@id='account-register']/div[1]").text == expected_warning


@then(u'Proper warning message for every mandatory fields should be displayed')
def step_impl(context):
    expected_privacy_policy_warning = "Warning: You must agree to the Privacy Policy!"
    expected_first_name_warning = "First Name must be between 1 and 32 characters!"
    expected_last_name_warning = "Last Name must be between 1 and 32 characters!"
    expected_email_address_warning = "E-Mail Address does not appear to be valid!"
    expected_telephone_warning = "Telephone must be between 3 and 32 characters!"
    expected_password_warning = "Password must be between 4 and 20 characters!"

    assert context.driver.find_element(By.XPATH, "//*[@id='account-register']/div[1]") \
        .text.__contains__(expected_privacy_policy_warning)

    assert context.driver.find_element(By.XPATH, "//input[@id='input-firstname']/following-sibling::div") \
               .text == expected_first_name_warning

    assert context.driver.find_element(By.XPATH, "//input[@id='input-lastname']/following-sibling::div") \
               .text == expected_last_name_warning

    assert context.driver.find_element(By.XPATH, "//input[@id='input-email']/following-sibling::div") \
               .text == expected_email_address_warning

    assert context.driver.find_element(By.XPATH, "//input[@id='input-telephone']/following-sibling::div") \
               .text == expected_telephone_warning

    assert context.driver.find_element(By.XPATH, "//input[@id='input-password']/following-sibling::div") \
               .text == expected_password_warning
