from behave import *
from selenium import webdriver
from selenium.webdriver.common.by import By


@given(u'I got navigated to Home page')
def step_impl(context):
    context.driver = webdriver.Chrome()
    context.driver.maximize_window()
    context.driver.get('https://tutorialsninja.com/demo/')


@when(u'I enter valid product into the Search box field')
def step_impl(context):
    context.driver.find_element(By.NAME, "search").send_keys("HP")


@when(u'I click on Search button')
def step_impl(context):
    context.driver.find_element(By.XPATH, "//*[@id='search']//button").click()


@then(u'Valid product should get displayed in Search result')
def step_impl(context):
    assert context.driver.find_element(By.LINK_TEXT, "HP LP3065").is_displayed()
    context.driver.quite()


@when(u'I enter invalid product into the Search box field')
def step_impl(context):
    context.driver.find_element(By.NAME, "search").send_keys("Honda")


@then(u'Proper message should be displayed in Search result')
def step_impl(context):
    expected_text = "There is no product that matches the search criteria."
    assert context.driver.find_element(By.XPATH, "//*[@id='button-search']/following-sibling::p").text.__eq__(expected_text)


@when(u'I dont enter anything into Search box field')
def step_impl(context):
    context.driver.find_element(By.NAME, "search").send_keys("")
